// Question : Write a program to create a Zombie state of the running program

#include <sys/types.h> // Import for `fork` system call
#include <unistd.h>    // Import for `fork` system call
#include <stdio.h>     // Import for `printf` function

void main()
{
    pid_t childPid;
    childPid = fork();
    if (childPid == 0)
    {
        // Only child process can enter
        printf("Child PID: %d\n", getpid());
        _exit(0);
    }
    else
    {
        sleep(2);
        printf("Parent is now awake!\n");
        printf("Parent PID: %d\n", getpid());
    }
    return 0;
}