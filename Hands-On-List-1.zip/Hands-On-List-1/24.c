// Question : Write a program to create an orphan process

#include <sys/types.h> // Import for `fork` system call
#include <unistd.h>    // Import for `fork` system call
#include <stdio.h>     // Import for `printf` function

void main()
{
    pid_t childPid;
    childPid = fork();
    if (childPid == 0) // child id
    {
        printf("i am child and go into sleep\n");
        sleep(2);
        printf("my parent id is  %d\n", getppid());
        printf("i am child having id %d \n", getpid());
    }
    else // parent id
    {
        printf("parent pid is %d\n", getpid());
    }
}