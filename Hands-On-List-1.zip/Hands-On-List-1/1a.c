// Question: Create a soft link file using the `symlink` system call

#include <unistd.h> // Import for `symlink` & `write` system calls
#include <stdio.h>  // Import for `perror` & `printf` functions

// argv[1] -> File path
// argv[2] -> Soft Link File path
void main(int argc, char *argv[])
{

    int status; // 0 -> Success, -1 -> Error

    if (argc != 3)
        printf("Enter File path and Symbolic Link File path as the arguments to the program\n");
    else
    {

        status = symlink(argv[1], argv[2]);

        if (status == -1)
            perror("Error while creating hard link!");
        else
            printf("Successfully created a soft link. Check with the `ll` or `ls -l` command.\n");
    }
}