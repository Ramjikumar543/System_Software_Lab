// Question : Write a program, open a file, call fork, and then write to the file by both the child as well as the parent processes.
// Check output of the file

#include <unistd.h>    // Import for `fork` system call
#include <sys/types.h> // Import for `open`, `fork` system call
#include <sys/stat.h>  // Import for `open` system call
#include <fcntl.h>     // Import for `open` system call

void main()
{
    int forkvalue, fileDescriptor;
    fileDescriptor = open("file.c", O_CREAT | O_WRONLY | O_APPEND, S_IRWXU);
    forkvalue = fork();
    if (forkvalue != 0) // Only parent can enter
        write(fileDescriptor, "i am parent", 12);
    else // Only child can enter
        write(fileDescriptor, "i am child\n!", 12);
    close(fileDescriptor);
}
