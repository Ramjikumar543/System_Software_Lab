// Question : Write a program, call fork and print the parent and child process id.

#include <sys/types.h> // Import for `fork` & `getpid` system call
#include <unistd.h>    // Import for `fork` & `getpid` system call
#include <stdio.h>     // Import for printf function

void main()
{
    pid_t p;
    p = fork();
    if (p == 0)
    {
        printf("Child PID: %d\n", getpid());   // child pid
        printf("Parent PID: %d\n", getppid()); // parent pid
    }
}
